#include "mockdiameterstack.hpp"

MockDiameterStack::MockDiameterStack() {}
MockDiameterStack::~MockDiameterStack() {}
